from extract import process, normalize
from rotplot import rotplot
import matplotlib.pyplot as plt

import os

def rotplotter(accrot, gyrorot, madgrot, viconrot):

	dir = os.getcwd()
	directory = (dir + "/Rotplots")
	for x in range(len(viconrot)):
		if x%7 == 0:
			rotplot(viconrot[x])
			name = directory + "/Raw1/Vicon/"+"{}".format(x)+".jpg"
			plt.savefig(name)
			plt.clf()
	return 0


if __name__ == "__main__":
	rotplotter()
