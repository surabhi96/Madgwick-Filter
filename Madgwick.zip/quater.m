syms a b c

quaternion([(cos(a/2)*cos(b/2)*cos(c/2) + sin(a/2)*sin(b/2)*sin(c/2)), 123, 123, 123 ]

