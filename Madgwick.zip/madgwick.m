imuRaw1 = load("imuRaw10.mat"); imuRaw1t = transpose(imuRaw1.vals);
imuParams = load("IMUParams.mat");
viconRot1 = load("viconRot6.mat");
a_x = imuRaw1t(:,1);
a_y = imuRaw1t(:,2);
a_z = imuRaw1t(:,3);
w_z = imuRaw1t(:,4);
w_x = imuRaw1t(:,5);
w_y = imuRaw1t(:,6);
bias_avg = 200;
bias_wx = mean(w_x(1:200));
bias_wy = mean(w_y(1:200));
bias_wz = mean(w_z(1:200));
scale_a = imuParams.IMUParams(1,:);
bias_a = imuParams.IMUParams(2,:);
ax = a_x*scale_a(1) + bias_a(1);
ay = a_y*scale_a(2) + bias_a(2);
az = a_z*scale_a(3) + bias_a(3);
wx = (3300/1023)*(pi/180)*0.3*(w_x-bias_wx);
wy = (3300/1023)*(pi/180)*0.3*(w_y-bias_wy);
wz = (3300/1023)*(pi/180)*0.3*(w_z-bias_wz);
phi = []; theta = []; psi =[];


rotviconarr = []
len_imu = size(imuRaw1t);
len_vicon = size(viconRot1.rots);
phi_vicon = []; theta_vicon = []; psi_vicon = [];
for i = 1:len_vicon(3)
eul = rotm2eul(viconRot1.rots(:,:,i));
rotvicon = eul2rotm(eul);
% rotviconarr = [rotviconarr; rotvicon];
rotviconarr(:,:,i) = rotvicon;
phi_vicon = [phi_vicon; eul(1)];
theta_vicon = [theta_vicon; eul(2)];
psi_vicon = [psi_vicon; eul(3)];
end
len_ts = length(imuRaw1.ts);
ts = [];
for i=1:(len_ts-1)
ts = [ts; imuRaw1.ts(i+1) - imuRaw1.ts(i)];
end

%% Acc_orientation
for i = 1:len_imu(1)
phi = [phi; atan2(ay(i), sqrt(ax(i)^2 + az(i)^2))];
theta = [theta; atan2(ax(i), sqrt(ay(i)^2 + az(i)^2))];
psi = [psi; atan2(sqrt(ax(i)^2 + ay(i)^2), az(i))];
end

% figure
% plot(1:len_imu(1), psi, 'r', 1:len_vicon(3), psi_vicon, 'g')

%% Madgwick Acceleration
close all
qk0 = [1 0 0 0];
beta = 0.005;
mad_acc_orient = [];
rotaccarr = []
for i = 1:(len_imu-1)
eul = quat2eul(qk0);
q1 = qk0(1); q2 = qk0(2); q3 = qk0(3); q4 = qk0(4);
acceleration = [0 ax(i), ay(i), az(i)]; acceleration = acceleration./norm(acceleration);
F = [2*(q2*q4 - q1*q3) - acceleration(2);
2*(q1*q2 + q3*q4) - acceleration(3);
2*(0.5 - q2^2 - q3^2) - acceleration(4)];
J = [-2*q3, 2*q4, -2*q1, 2*q2;
2*q2, 2*q1, 2*q4, 2*q3;
0, -4*q2, -4*q3, 0];
delf = J'*F;
delf = delf./norm(delf);
qk1 = qk0 - beta*delf';
qk0 = qk1./norm(qk1);
mad_acc_orient = [mad_acc_orient; eul];
rot_acc = eul2rotm(eul);
% rotaccarr = [rotaccarr; rot_acc];
rotaccarr(:,:,i) = rot_acc;
end
phi_acc = mad_acc_orient(:,1);
theta_acc = mad_acc_orient(:,2);
psi_acc = mad_acc_orient(:,3);
% figure
% plot(1:len_imu(1), phi_acc, 'r',...
% 1:len_vicon(3), phi_vicon, 'g')

%% Madgwick gyro
close all
qk0 = [1 0 0 0];
rotgyroarr = [];
mad_gyro_orient = [quat2eul(qk0)];
for i = 1:(len_imu-1)
w = [0 wx(i) wy(i) wz(i)];
q_dot = 0.5*quatmultiply(qk0, w);
%qk1 = qk0 + q_dot*ts(i);
qk1 = qk0 + q_dot*mean(ts);
eul = quat2eul(qk1);
qk0 = qk1./norm(qk1);
mad_gyro_orient = [mad_gyro_orient; eul];
rotgyro = eul2rotm(eul);
% rotgyroarr = [rotgyroarr; rotgyro];
rotgyroarr(:,:,i) = rotgyro;
end
phi_gyro = mad_gyro_orient(:,1);
theta_gyro = mad_gyro_orient(:,2);
psi_gyro = mad_gyro_orient(:,3);
% figure
% y1 = psi_gyro;
% plot(1:len_imu(1), y1, 'r')
% hold on
% y2 = psi_acc; y3 = psi_vicon;
% plot(1:len_imu(1), y2, 'b')
% plot(1:len_vicon(3), y3, 'g')
%
% legend('psi gyro', 'psi acc', 'psi vicon')
%% Madgwick filter
close all;
beta = 0.03
qk0 = [1 0 0 0];
madg_orient = [];
madg_orient = [quat2eul(qk0)];
rotmadarr = []

for i = 1:(len_imu(1)-1)
w = [0 wx(i) wy(i) wz(i)];
acceleration = [0 ax(i), ay(i), az(i)]; acceleration = acceleration./norm(acceleration);
q1 = qk0(1); q2 = qk0(2); q3 = qk0(3); q4 = qk0(4);
F = [2*(q2*q4 - q1*q3) - acceleration(2);
2*(q1*q2 + q3*q4) - acceleration(3);
2*(0.5 - q2^2 - q3^2) - acceleration(4)];
J = [-2*q3, 2*q4, -2*q1, 2*q2;
2*q2, 2*q1, 2*q4, 2*q3;
0, -4*q2, -4*q3, 0];
delf = J'*F;
delf = delf./norm(delf);

q_dot1 = 0.5*quatmultiply(qk0, w);

q_intermediate = q_dot1 - beta*delf';
qk1 = qk0 + q_intermediate*ts(i);
qk0 = qk1./norm(qk1);
eul = quat2eul(qk1);

rotmad = eul2rotm(eul);
rotmadarr(:,:,i) = rotmad;
madg_orient = [madg_orient; eul];
end

phi_madg = madg_orient(:,1); 
theta_madg = madg_orient(:,2); 
psi_madg = madg_orient(:,3); 

angle = 0

if angle == 0
    genname = 'phi';
    gyro_name = phi_gyro;
    vicon_name = phi_vicon;
    acc_name = phi_acc;
    madg_name = phi_madg;
elseif angle == 1
    genname = 'theta';
    gyro_name = theta_gyro;
    vicon_name = theta_vicon;
    acc_name = theta_acc;
    madg_name = theta_madg;
elseif angle == 2
    genname = 'psi';
    gyro_name = psi_gyro;
    vicon_name = psi_vicon;
    acc_name = psi_acc;
    madg_name = psi_madg;
end

% f1 = figure;
% y1 = gyro_name;
% plot(1:len_imu(1), y1, 'c');
% hold on 
% y2 = acc_name;
% plot(1:len_imu(1), y2, 'b');
% y3 = madg_name;
% plot(1:len_imu(1), y3, 'r');
% % y4 = vicon_name;
% % plot(1:len_vicon(3), y4, 'g');
% %  
% legend(strcat(genname,'gyro'), strcat(genname,'acc'),strcat(genname,'madg'))% strcat(genname,'vicon'));
% name = strcat('imuraw10_',genname);
% saveas(f1,name,'jpg');

save('rotaccarr_raw10.mat','rotaccarr');
% save('rotviconarr_raw6.mat','rotviconarr');
save('rotgyroarr_raw10.mat','rotgyroarr');
save('rotmadarr_raw10.mat','rotmadarr');