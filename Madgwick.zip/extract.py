from __future__ import division
from scipy import io,constants
import os
import numpy as np
from rotplot import rotplot
import matplotlib.pyplot as plt

def acctransform(a,b,s):
    # print(type(a))
    # a = np.float16(a)
    # b = np.float16(b)
    # s = np.float16(s)
    a_new = float(a)*float(s) + float(b)
    return a_new
    # return a

def normalize(a):
    avg = np.mean(a)
    stdev = np.std(a)
    a_new = []
    
    a_new = [(number-avg)/stdev for number in a]
    return a_new

def angtransform(w,bg):
    wnew = (3300/1023)*(np.pi/180)*0.3*(w-bg)
    return wnew
    # return w

def bias_compute(dataimu,k,val):

    # print(len(dataimu))

    # start = dataimu[0][3]

    # for idx in range(len(dataimu)-1):
        # if float(dataimu[idx][3]) - float(start) > 2:
        #     break
        # else:
        #     continue

    elements = dataimu[0:k]
    if val == 0:
        bias = np.mean(elements,axis=0)[3]
    elif val == 1:
        bias = np.mean(elements,axis=0)[4]
    else:
        bias = np.mean(elements,axis=0)[5]
    # bias = 1/k(np.sum(elements[3]))

    return bias


def process():

    dir = os.getcwd()

    directoryid = str(dir+"/Data/Train/IMU/imuRaw1.mat")

    viconid = str(dir+"/Data/Train/Vicon/viconRot1.mat")
    
    x = io.loadmat(directoryid)
    
    imudata = io.loadmat(dir+"/IMUParams.mat")
    imuparams = imudata['IMUParams']
    
    y = io.loadmat(viconid)
    
    # IMU data initialize
    ax, ay, az, wx, wy, wz = [], [], [], [], [], []
    sx, sy, sz = imuparams[0]
    bax,bay,baz = imuparams[1]
    # print(sx)
    # Vicon data initialize
    time, rots, time_imu = [], [], []

    dataimu = x['vals'].transpose()
    dataimu_ts = x['ts'].transpose()

    bias_psi = float(bias_compute(dataimu,200,0))
    bias_phi = float(bias_compute(dataimu,200,1))
    bias_theta = float(bias_compute(dataimu,200,2))
    # print(dataimu)

    # print(data)
    for row in dataimu:
        # ax.append(row[0])
        ax.append(acctransform(row[0],bax,sx))
        ay.append(acctransform(row[1],bay,sy))
        az.append(acctransform(row[2],baz,sz))

        wz.append(angtransform(row[3],bias_psi))
        wx.append(angtransform(row[4],bias_phi))
        wy.append(angtransform(row[5],bias_theta))

    datavicon_rots = y['rots']
    datavicon_ts = y['ts']

    datavicon_rots = datavicon_rots.transpose()
    datavicon_ts = datavicon_ts.transpose()

    for ts in datavicon_ts:
        time.append(float(ts))

    for ts in dataimu_ts:
        time_imu.append(float(ts))

    # rotplot(datavicon_rots[5550])
    # plt.show()

    # ax = normalize(ax)
    # wx = normalize(wx)
    return ax,ay,az,wx,wy,wz,datavicon_rots,time,time_imu, directoryid, viconid

if __name__ == "__main__":

    process()
