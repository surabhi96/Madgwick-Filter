from __future__ import division
import time
import math
import numpy as np
import os
import cv2
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d as a3
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Polygon
import re


from rotplotter import rotplotter
from extract import process, normalize
from rotplot import rotplot

from pyquaternion import Quaternion

def plotter(data, ax=None, **kwargs):
    
    plt.plot(data, **kwargs)
    # plt.draw()
    return 0

def timediff():

    if len(datavicon_rots)>len(ax):
        chosen = time
    else:
        chosen = time_imu

    init = chosen[0]
    diff = []

    for i in range(len(chosen)-2):
        diff.append(chosen[i+1] - init)
        init = chosen[i]

    return diff

def rot2quat(R):
    # print(R)
    # eigmat = np.linalg.eig(R)
    # print(eigmat)
    quaternion = Quaternion(matrix=R)

    return quaternion

def norm(A):
    return ((A-np.mean(A))/np.std(A))

def normalize(x):
    # xmax, xmin = x.max(), x.min()
    # mean, stdev = np.avg(x), np.std(x)
    # x = (x - xmin)/(xmax - xmin)

    a,b,c,d = x[0],x[1],x[2],x[3]

    norm = np.sqrt(np.square(a) + np.square(b) + np.square(c) + np.square(d))

    x = x/norm

    # print(x)
    return x

def normalize_quat(x):

    q0,q1,q2,q3 = x.elements

    norm = np.sqrt(np.square(q0) + np.square(q1) + np.square(q2) + np.square(q3))

    q0n, q1n, q2n, q3n = q0/norm, q1/norm, q2/norm, q3/norm

    q_new = Quaternion(q0n, q1n, q2n, q3n)

    # q0, q1, q2, q3 = q_new.elements

    # print(q_new)
    return q_new

def quat2eul(q_final):
    qw, qx, qy, qz = q_final.elements
    # heading = np.arctan2(2*qy*qw - 2*qx*qz, 1 - 2*np.square(qy) - 2*np.square(qz))
    # attitude = np.arcsin(2*qx*qy + 2*qz*qw)
    # bank = np.arctan2(2*qx*qw - 2*qy*qz , 1 - 2*np.square(qx) - 2*np.square(qz))

    sinr_cosp = 2.0 * (qw * qx + qy * qz)
    cosr_cosp = 1.0 - 2.0*(qx*qx+ qy * qy)
    roll = np.arctan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (qw * qy - qz * qx);
    if (np.fabs(sinp) >= 1):
        pitch = np.copysign(np.pi/2, sinp)
    else:
        pitch = np.arcsin(sinp)

    siny_cosp = 2.0 * (qw*qz + qx*qy);
    cosy_cosp = 1.0 - 2.0*(qy*qy + qz* qz)  
    yaw = np.arctan2(siny_cosp, cosy_cosp)

    euler = [roll, pitch, yaw]
    return euler

# def quat2eul(q):
#     w,x,y,z = q.q
#     R11 = 1-2*(y**2 +z**2)
#     R21 = 2*(w*z + x*y)
#     R31 = 2*(x*z+w*y)
#     R32 = 2*(y*z-w*x)
#     R33 = 2*(w**2)-1+2*(z**2)
#     if R31**2 >=1.0:
#     # print "true"
#         R31 = 0.99499
   
#     phi = math.atan2(R32, R33 )*(180/np.pi);
#     theta = -math.atan(R31/math.sqrt(1-R31**2))*(180/np.pi);
#     psi = math.atan2(R21, R11 )*(180/np.pi);
#     return [phi, theta, psi]

def quat2eul_1(q_final):
    qw, qx, qy, qz = float(q_final[0]), float(q_final[1]), float(q_final[2]), float(q_final[3])
    # heading = np.arctan2(2*qy*qw - 2*qx*qz, 1 - 2*np.square(qy) - 2*np.square(qz))
    # attitude = np.arcsin(2*qx*qy + 2*qz*qw)
    # bank = np.arctan2(2*qx*qw - 2*qy*qz , 1 - 2*np.square(qx) - 2*np.square(qz))

    sinr_cosp = 2.0 * (qw * qx + qy * qz)
    cosr_cosp = 1.0 - 2.0*(qx*qx+ qy * qy)
    roll = np.arctan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (qw * qy - qz * qx);
    if (np.fabs(sinp) >= 1):
        pitch = np.copysign(np.pi/2, sinp)
    else:
        pitch = np.arcsin(sinp)

    siny_cosp = 2.0 * (qw*qz + qx*qy);
    cosy_cosp = 1.0 - 2.0*(qy*qy + qz* qz)  
    yaw = np.arctan2(siny_cosp, cosy_cosp)

    euler = [roll,pitch,yaw]
    return euler

def rot2eul(R):
    r11, r21, r31, r32, r33 = R[0,0], R[1,0], R[2,0], R[2,1], R[2,2]

    phi = np.arctan2(r32,r33)
    theta = np.arctan2(-1*r31, np.sqrt(np.square(r32) + np.square(r33)))
    psi = np.arctan2(r21,r11)

    R_new = [phi, theta, psi]
    return R_new

def eul2axis(E):

    phi, theta, psi = E[0], E[1], E[2]

    c1, c2, c3 = np.cos(psi/2), np.cos(theta/2), np.cos(phi/2)
    s1, s2, s3 = np.sin(psi/2), np.sin(theta/2), np.sin(phi/2)

    angle = 2*np.arccos(c1*c2*c3 - s1*s2*s3)

    rx = s1*s2*c3 + c1*c2*s3
    ry = s1*c2*c3 + c1*s2*s3
    rz = c1*s2*c3 - s1*c2*s3

    E_new = [angle, rx, ry, rz]

    # print(E_new)

    return E_new

def axis2quat(A):

    angle, rx, ry, rz = A[0], A[1], A[2], A[3]

    qx = rx*np.sin(angle/2)
    qy = ry*np.sin(angle/2)
    qz = ry*np.sin(angle/2)
    qw = np.cos(angle/2)

    quat = [qw, qx, qy, qz]

    return quat


def quat2axis(q_final):
    qw, qx, qy, qz = q_final.elements

    angle = 2*np.arccos(qw)
    x = (qx)/np.sqrt(1-np.square(qw))
    y = (qy)/np.sqrt(1-np.square(qw))
    z = (qz)/np.sqrt(1-np.square(qw))

    # if np.square(qw) > 1:
    #     print("GREATER THAN ONE!" + str(np.square(qw)))
    #     print(x_new[0])

    axis = [angle, x, y, z]

    return axis


def quat2axis_1(q_final):
    qw, qx, qy, qz = float(q_final[0]), float(q_final[1]), float(q_final[2]), float(q_final[3])

    angle = 2*np.arccos(qw)
    x = (qx)/np.sqrt(1-np.square(qw))
    y = (qy)/np.sqrt(1-np.square(qw))
    z = (qz)/np.sqrt(1-np.square(qw))
    # if np.square(qw) > 1:
    #     print("GREATER THAN ONE!" + str(np.square(qw)))
        # print(x_new[0])

    axis = [angle, x, y, z]

    return axis


def axis2euler(axis):

    angle, x, y, z = axis[0], axis[1], axis[2], axis[3]

    psi = np.arctan2(y*np.sin(angle)- x * z * (1 - np.cos(angle)), 1 - (np.square(y) + np.square(z) ) * (1 - np.cos(angle)))

    theta = np.arcsin(x * y * (1 - np.cos(angle)) + z*np.sin(angle))
    
    phi = np.arctan2(x * np.sin(angle)-y * z * (1 - np.cos(angle)) , 1 - (np.square(x) + np.square(z) * (1 - np.cos(angle))))

    euler = [phi,theta,psi]

    return euler


def euler2rot(E):

    phi, theta, psi = E[0], E[1], E[2]

    c1, c2, c3 = np.cos(psi), np.cos(theta), np.cos(phi)
    s1, s2, s3 = np.sin(psi), np.sin(theta), np.sin(phi)

    Rotmat = np.matrix([[c1*c2, c1*s2*s3 - c3*s1, s1*s2+c1*c3*s2],[c2*s1, c1*s3+s1*s2*s3, c3*s1*s2-c1*s3],[-1*s2, c2*s3, c2*c3]])

    return Rotmat


def vicon_data():

    global VICON_LABEL, ANGLE
    if len(datavicon_rots)>len(ax):
        chosen = len(ax)
    else:
        chosen = len(datavicon_rots)

    points_vicon, rotmatarr = [], []
    for x in range(chosen-1):

        # Converting Vicon data to Euler angles
        R_new = rot2eul(datavicon_rots[x])
        # # Converting Euler angles to axis angles
        # E_new = eul2axis(R_new)

        points_vicon.append(R_new[ANGLE])

        rotmat = euler2rot(R_new)

        rotmat = np.array(rotmat)

        rotmatarr.append(rotmat)

    plotter(points_vicon,'r',label=VICON_LABEL)
    plt.legend()

    return rotmatarr


def quat_mul(q1,q2):

    w1, x1, y1, z1 = q1.elements

    w2, x2, y2, z2 = q2.elements

    wmat = np.matrix([[w1*w2 - x1*x2 - y1*y2 - z1*z2], [w1*x2 + w2*x1 + y1*z2 - y2*z1], [w1*y2 + w2*y1 - x1*z2 + x2*z1], [w1*z2 + w2*z1 + x1*y2 + x2*y1]])

    qmul = Quaternion(wmat[0],wmat[1],wmat[2],wmat[3])

    return qmul


### DO NOT USE!
# def gyro_orientation():
#     global GYRO_LABEL

#     time_diff = timediff()

#     wx1, wy1, wz1 = [], [], []

#     init = [0, 0, 0]
#     # Rot = rot2eul(datavicon_rots[0])
#     Rot = init

#     wx1.append(Rot[0])
#     wy1.append(Rot[1])
#     wz1.append(Rot[2])

#     for x in range(len(wx)-2):
#         wx1.append(wx1[x] + wx[x]*time_diff[x])
#         wy1.append(wy1[x] + wy[x]*time_diff[x])
#         wz1.append(wz1[x] + wz[x]*time_diff[x])

#     plotter(wx1,'r',label=GYRO_LABEL)
#     plt.legend()

#     return 0

def acc_orientation():
    if len(datavicon_rots)>len(ax):
        chosen = len(ax)
    else:
        chosen = len(datavicon_rots)

    roll, pitch, yaw = [], [], []
    eulerarr = []

    for x in range(chosen-1):
        ax_cur, ay_cur, az_cur = ax[x], ay[x], az[x]

        roll.append(np.arctan2(ay_cur, np.sqrt(np.square(ax_cur) + np.square(az_cur))))
        pitch.append(np.arctan2(-ax_cur, np.sqrt(np.square(ay_cur) + np.square(az_cur))))
        yaw.append(np.arctan2(np.sqrt(np.square(ax_cur) + np.square(ay_cur)), az_cur))

    # plt.plot(roll,'r--',label='IMU_phi')
    if ANGLE == 0:
        plotter(roll,'r',label=ACC_LABEL)
    elif ANGLE == 1:
        plotter(pitch,'r',label=ACC_LABEL)
    else:
        plotter(yaw,'r',label=ACC_LABEL)
    # plt.plot(pitch,'g--',label='theta')
    # plt.plot(yaw,'b--',label='psi')

    plt.legend()
    # plt.show()
    # pass
# ### DO NOT USE!

def Madgwick_acc(beta):

    global ANGLE, ACC_LABEL

    if len(datavicon_rots)>len(ax):
        chosen = len(ax)
    else:
        chosen = len(datavicon_rots)

    eulerarr,rotmatarr = [], []

    # Converting Vicon data to Euler angles
    # R_new = rot2eul(datavicon_rots[0])
    # Converting Euler angles to axis angles
    # E_new = eul2axis(R_new)
    final_q = Quaternion()

    # quat = Quaternion(axis = [float(axis[1]),float(axis[2]),float(axis[3])], angle = float(axis[0]))

    # axis = [float(E_new[0]), float(E_new[1]), float(E_new[2]), float(E_new[3])]
    decrement, inval= [], []

    for x in range(chosen - 1):
        xval, yval, zval = ax[x], ay[x], az[x]

        # quat = axis2quat(E_new)

        # Converting to quaternion
        quat = final_q

        q1,q2,q3,q4 = quat.elements

        F = np.matrix([[2*(q2*q4-q1*q3) - xval], [2*(q1*q2 + q3*q4) - yval], [2*(0.5 - np.square(q2) - np.square(q3)) - zval]])

        J = np.matrix([[-2*q3, 2*q4, -2*q1, 2*q2], [2*q2, 2*q1, 2*q4, 2*q3], [0, -4*q2, -4*q3, 0]])

        # plt.plot(ax,'r--',label='ax')
        # plt.plot(ay,'g--',label='ay')
        # plt.plot(az,'b--',label='az')

        delf = np.matmul(J.transpose(),F)

        delf = delf/(np.linalg.norm(delf))

        # delf = normalize(delf)

        # print(delf)

        # E = axis2quat(E_new)

        # quat = axis2quat(E_new)

        # Converting to quaternion
        # quat = Quaternion(axis = [E_new[1],E_new[2],E_new[3]], angle = E_new[0])

        quat_arr = np.matrix([[q1],[q2],[q3],[q4]])

        delf1 = delf

        delf = Quaternion(delf[0],delf[1],delf[2],delf[3])

        decrement.append(-1*beta*delf)

        final_q = normalize(quat_arr)-1*beta*delf1

        # final_q = normalize(final_q)

        final_q_inv = [final_q[0], -final_q[1], -final_q[2], -final_q[3]]

        euler = quat2eul_1(final_q_inv)

        # axis = quat2axis_1(final_q)

        # euler = axis2euler(axis)

        rotmat = euler2rot(euler)

        rotmat = np.array(rotmat)

        rotmatarr.append(rotmat)

        eulerarr.append(euler)

        final_q = Quaternion(float(final_q[0]), float(final_q[1]), float(final_q[2]), float(final_q[3]))

        inv = final_q.inverse

        inval.append(quat2eul(inv))

    # print(np.array(eulerarr).transpose()[0])

    # plotter(np.array(eulerarr).transpose()[0],'r--', label='Acc_phi')
    plotter(np.array(inval).transpose()[ANGLE],'r--', label=ACC_LABEL)
    # plt.legend()
    # plt.plot(points_vicon,'b--', label='Vicon_theta')
    return decrement, rotmatarr, inval


def complementary_filter(acc,gyro):

    aphi, atheta, apsi = acc[0], acc[1], acc[2]
    gphi, gtheta, gpsi = gyro[0], gyro[1], gyro[2]

    alpha = 0.75
    beta = 0.75 
    gamma = 1.0

    cphi = alpha*aphi + (1-alpha)*gphi
    ctheta = alpha*atheta + (1-alpha)*gtheta
    cpsi = alpha*apsi + (1-alpha)*gpsi

    return [cphi, ctheta, cpsi]



def Madgwick_gyro():

    global ANGLE, GYRO_LABEL
    # fig = plt.figure()
    xdata,ydata = [], []
    axes = plt.gca()
    axes.set_xlim(0, 6000)
    # axes.set_ylim(-0.0012, +0.0005)
    line, = axes.plot(xdata, ydata, 'r')

    points_vicon = []
    points = []
    rotmatarr = []
    q_dotarr = []
    eulerarr = []

    if len(datavicon_rots)>len(wx):
        chosen = len(wx)
    else:
        chosen = len(datavicon_rots)

    q_final = Quaternion()

    for x in range(chosen-1):

        # quat = axis2quat(E_new)

        # Converting Vicon data to Euler angles
        # R_new = rot2eul(datavicon_rots[x])
        # Converting Euler angles to axis angles
        # E_new = eul2axis(R_new)

        # # Converting to quaternion
        # quat = Quaternion(axis = [E_new[1],E_new[2],E_new[3]], angle = E_new[0])
        # quat = rot2quat(datavicon_rots[x])
        # quat = Quaternion(matrix=datavicon_rots[x])
        # quat = axis2quat(eul2axis(euler))

        quat = normalize_quat(q_final)

        w_inertial = Quaternion(0, wx[x], wy[x], wz[x])

        # print(quat)
        # quat = normalize_quat(quat)
        # w_inertial = w_inertial.normalised


        gyro = quat_mul(quat, w_inertial)

        # print(qk)
        
        q_dot = 0.5*gyro # OUR DIFERENTIATION

        # q_dot = normalize_quat(q_dot)

        q_final = quat + q_dot*0.0075 # OUR INTEGRATION

        # q_final = normalize_quat(q_final)

        # q_dot, q_final = attitude(quat, w_inertial, timediff()[x])

        q_dotarr.append(q_dot)

        # q_final = q_final.normalised

        # q_dot = q_dot.normalised

        inv = q_final.inverse

        # axis = quat2axis(inv)

        # euler = axis2euler(axis)
    
        inval = quat2eul(inv)

        # euler = quat2eul(q_final)
        rotmat = euler2rot(inval)

        rotmat = np.array(rotmat)

        rotmatarr.append(rotmat)

        eulerarr.append(inval)

        # rotplot(rotmat)
        # quat = rot2quat(datavicon_rots[x])

        # 0 - Phi, 1 - Theta, 2 - Psi
        points.append(inval)
        # fig = rotplot(rotmat)

    plotter(np.array(points).transpose()[ANGLE],'r',label=GYRO_LABEL)
    plt.legend()
    # q = [0 R_new[0] R_new[1] R_new[2]]
    return points, points_vicon, q_dotarr, rotmatarr, eulerarr


def Madgwick(descent,qdot,difftime):
    
    if len(datavicon_rots)>len(ax):
        chosen = len(ax)
    else:
        chosen = len(datavicon_rots)

    madarr = []

    for i in range(chosen-1):
        madarr.append(qdot[i] + descent[i])

    madinit = Quaternion(1,0,0,0)

    inveularr,rotmatarr = [], []

    for i in range(chosen - 2):

        # madinit = normalize_quat(madinit)

        madfinal = madinit + madarr[i]*0.0075

        madinit = madfinal

        madinv = madfinal.inverse

        inveul = quat2eul(madinv)

        inveularr.append(inveul[ANGLE])

        rotmat = euler2rot(inveul)

        rotmat = np.array(rotmat)

        rotmatarr.append(rotmat)

    # plotter(wx,'r',label='Wx')
    # plotter(inveularr,'r',label=MADGWICK_LABEL)
    # plt.legend()

    return rotmatarr

def complement(accarr, gyroarr):

    angles = []

    for i in range(len(accarr)-1):
        angles.append(complementary_filter(accarr[i], gyroarr[i]))

    l =map(list, zip(*angles))
    # print(len(l))
    plotter(l[ANGLE],'r',label = COMPLEMENTARY_LABEL)
    plt.legend()

if __name__ == "__main__":

    ax,ay,az,wx,wy,wz,datavicon_rots,time,time_imu,directoryid, viconid = process()
    number = 0
    # for number in range(3):
    ANGLE = number

    if ANGLE == 0:
        LABEL = 'phi'

    elif ANGLE == 1:
        LABEL = 'theta'
    else:
        LABEL = 'psi'

    str = directoryid

    # numberarr = [int(s) for s in str.split() if s.isdigit()]
    print

    numberarr = re.findall(r'\d+', directoryid)

    VICON_LABEL = 'Vicon_' + LABEL 
    ACC_LABEL = 'Acc_' + LABEL
    GYRO_LABEL = 'Gyro_' + LABEL
    MADGWICK_LABEL = 'Madgwick_' + LABEL
    COMPLEMENTARY_LABEL = 'Complementary_' + LABEL

    # rot2quat(datavicon_rots[0])
    # axis2quat(eul2axis(rot2eul(datavicon_rots[0])))
    gyro, vicon, qdot, gyrorot, gyroarr = Madgwick_gyro()
    descent, accrot, accarr = Madgwick_acc(beta=0.03)
    # madgrot = Madgwick(descent,qdot,timediff())
    viconrot = vicon_data()
    # acceleration = acc_orientation()
    # complement(accarr, gyroarr)
    # rotplotter(accrot,gyrorot,madgrot,viconrot)
    # gyro_orientation()
    plt.show()
    # name = "/home/vdorbala/ENAE788M/P1/Graph/Raw" + "{}".format(numberarr[2])+"/"+LABEL+".png"
    # plt.savefig(name)
    # plt.clf()